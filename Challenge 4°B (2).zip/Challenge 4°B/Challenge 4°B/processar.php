<?php
$servername = "localhost"; // ou o IP do seu servidor
$username = "root"; // seu usuário do MySQL
$password = ""; // sua senha do MySQL
$dbname = "bd_challenge4b"; // nome do seu banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Obter dados do formulário
$_internet = $_POST['_internet'];
$_senha = $_POST['_senha'];
$_permissao = $_POST['_permissao'];

// Preparar e vincular
$stmt = $conn->prepare("INSERT INTO  tb_cadastro (_internet, _senha, _permissao) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $_internet, _$senha, $_permissao);

// Executar e verificar
if ($stmt->execute()) {
    echo "Coneção realizado com sucesso!";
} else {
    echo "Erro: " . $stmt->error;
}

// Fechar conexão
$stmt->close();
$conn->close();
?>